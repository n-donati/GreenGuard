import numpy as np
import openvino as ov
from path

lrm
se puede instanciar, y luego correr multiples veces
